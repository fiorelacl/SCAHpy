# __init__.py

__all__ = [
    'in_out',
    'map_plots',
    'met_diag',
    'spatial_scales',
    'temp_scales',
]

# Version of scahpy package
__version__ = "0.0.11"
